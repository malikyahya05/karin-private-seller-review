import {env} from 'cloudflare:workers';
export function getDb(){if(!env.DB)throw new Error('The seller request service is unavailable.');return env.DB;}
