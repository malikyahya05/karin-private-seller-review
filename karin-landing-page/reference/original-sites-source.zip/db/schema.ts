import {sqliteTable,text,integer,index} from 'drizzle-orm/sqlite-core';
export const sellerReviews=sqliteTable('seller_reviews',{
 id:text('id').primaryKey(),name:text('name').notNull(),phone:text('phone').notNull(),email:text('email').notNull().default(''),address:text('address').notNull(),estimatedValue:text('estimated_value').notNull(),timeline:text('timeline').notNull(),message:text('message').notNull().default(''),attribution:text('attribution').notNull().default('{}'),createdAt:integer('created_at').notNull(),ipHash:text('ip_hash').notNull(),notificationStatus:text('notification_status').notNull().default('not_configured')
},(table)=>[index('idx_seller_reviews_ip_created').on(table.ipHash,table.createdAt)]);
