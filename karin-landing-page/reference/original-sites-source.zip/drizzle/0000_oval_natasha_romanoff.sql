CREATE TABLE `seller_reviews` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`phone` text NOT NULL,
	`email` text DEFAULT '' NOT NULL,
	`address` text NOT NULL,
	`estimated_value` text NOT NULL,
	`timeline` text NOT NULL,
	`message` text DEFAULT '' NOT NULL,
	`attribution` text DEFAULT '{}' NOT NULL,
	`created_at` integer NOT NULL,
	`ip_hash` text NOT NULL,
	`notification_status` text DEFAULT 'not_configured' NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_seller_reviews_ip_created` ON `seller_reviews` (`ip_hash`,`created_at`);